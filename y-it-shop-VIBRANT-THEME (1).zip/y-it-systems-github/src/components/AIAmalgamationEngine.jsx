import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Switch } from '@/components/ui/switch.jsx'
import { 
  ChevronDown, 
  ChevronUp, 
  Brain, 
  Settings, 
  Play, 
  Download,
  Upload,
  BarChart3,
  Clock,
  DollarSign
} from 'lucide-react'

const AIAmalgamationEngine = () => {
  const [selectedModels, setSelectedModels] = useState({
    chatgpt: { enabled: true, model: 'gpt-4-turbo' },
    claude: { enabled: false, model: 'claude-3-sonnet' },
    gemini: { enabled: false, model: 'gemini-pro' },
    perplexity: { enabled: false, model: 'perplexity-pro' },
    deepseek: { enabled: false, model: 'deepseek-v2' },
    llama: { enabled: false, model: 'llama-3-70b' }
  })

  const [expandedModels, setExpandedModels] = useState({})
  const [query, setQuery] = useState('')
  const [activePreset, setActivePreset] = useState('market-analysis')
  const [responseFormat, setResponseFormat] = useState('bullets')
  const [amalgamationMode, setAmalgamationMode] = useState('single')
  const [settings, setSettings] = useState({
    autoArchive: true,
    includeMetadata: false,
    versionControl: true,
    streamingMode: true,
    cacheResponses: true,
    batchRequests: false
  })

  const models = {
    chatgpt: {
      name: 'ChatGPT',
      options: [
        { id: 'gpt-4-turbo', name: 'GPT-4 Turbo', price: '$' },
        { id: 'gpt-4', name: 'GPT-4', price: '$$' },
        { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo', price: '$' }
      ]
    },
    claude: {
      name: 'Claude',
      options: [
        { id: 'claude-3-opus', name: 'Opus 3', price: '$$' },
        { id: 'claude-3-sonnet', name: 'Sonnet 3', price: '$' },
        { id: 'claude-3-haiku', name: 'Haiku 3', price: '$' }
      ]
    },
    gemini: {
      name: 'Gemini',
      options: [
        { id: 'gemini-ultra', name: 'Ultra', price: '$$' },
        { id: 'gemini-pro', name: 'Pro', price: '$' },
        { id: 'gemini-flash', name: 'Flash', price: 'FREE' }
      ]
    },
    perplexity: {
      name: 'Perplexity',
      options: [
        { id: 'perplexity-pro', name: 'Pro', price: '$' },
        { id: 'perplexity-standard', name: 'Standard', price: '$' }
      ]
    },
    deepseek: {
      name: 'DeepSeek',
      options: [
        { id: 'deepseek-v2', name: 'V2', price: '$' },
        { id: 'deepseek-coder', name: 'Coder', price: '$' }
      ]
    },
    llama: {
      name: 'Meta Llama',
      options: [
        { id: 'llama-3-70b', name: 'Llama 3 70B', price: 'FREE' },
        { id: 'llama-3-8b', name: 'Llama 3 8B', price: 'FREE' }
      ]
    }
  }

  const presets = [
    { 
      id: 'market-analysis', 
      title: 'Market Analysis', 
      tag: 'ROI', 
      desc: 'Analyze market trends with financial focus',
      color: 'from-emerald-500 to-teal-600',
      tagColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
    },
    { 
      id: 'technical-dive', 
      title: 'Technical Deep Dive', 
      tag: 'Dev', 
      desc: 'Code review and optimization analysis',
      color: 'from-blue-500 to-indigo-600',
      tagColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30'
    },
    { 
      id: 'content-strategy', 
      title: 'Content Strategy', 
      tag: 'Scale', 
      desc: 'SEO-optimized content generation',
      color: 'from-purple-500 to-violet-600',
      tagColor: 'bg-purple-500/20 text-purple-300 border-purple-500/30'
    },
    { 
      id: 'automation-audit', 
      title: 'Automation Audit', 
      tag: 'Ops', 
      desc: 'Identify automation opportunities',
      color: 'from-orange-500 to-red-600',
      tagColor: 'bg-orange-500/20 text-orange-300 border-orange-500/30'
    },
    { 
      id: 'competitor-intel', 
      title: 'Competitor Intel', 
      tag: 'Research', 
      desc: 'Deep competitive analysis',
      color: 'from-pink-500 to-rose-600',
      tagColor: 'bg-pink-500/20 text-pink-300 border-pink-500/30'
    },
    { 
      id: 'deal-analysis', 
      title: 'Deal Analysis', 
      tag: 'RE', 
      desc: 'Real estate investment evaluation',
      color: 'from-amber-500 to-yellow-600',
      tagColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30'
    }
  ]

  const responseFormats = ['Bullets', 'Paragraphs', 'Table', 'Graph', 'Code', 'JSON']
  const amalgamationModes = ['Single Model', 'Sequential', 'Parallel', 'Consensus', 'Debate']

  const toggleModel = (modelKey) => {
    setSelectedModels(prev => ({
      ...prev,
      [modelKey]: { ...prev[modelKey], enabled: !prev[modelKey].enabled }
    }))
  }

  const toggleModelExpansion = (modelKey) => {
    setExpandedModels(prev => ({
      ...prev,
      [modelKey]: !prev[modelKey]
    }))
  }

  const selectModelOption = (modelKey, optionId) => {
    setSelectedModels(prev => ({
      ...prev,
      [modelKey]: { ...prev[modelKey], model: optionId }
    }))
  }

  const calculateCost = () => {
    let total = 0
    Object.entries(selectedModels).forEach(([key, model]) => {
      if (model.enabled) {
        const modelData = models[key]
        const option = modelData.options.find(opt => opt.id === model.model)
        if (option) {
          if (option.price === '$$') total += 0.15
          else if (option.price === '$') total += 0.08
          else if (option.price === '¢') total += 0.02
        }
      }
    })
    return total.toFixed(2)
  }

  const getPriceClass = (price) => {
    switch (price) {
      case 'FREE': return 'price-free'
      case '¢': return 'price-low'
      case '$': return 'price-medium'
      case '$$': return 'price-high'
      default: return 'price-medium'
    }
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Sidebar - Model Selection */}
        <div className="lg:col-span-1">
          <Card className="glass">
            <CardHeader>
              <CardTitle className="text-lg">Model Selection</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(models).map(([key, model]) => (
                <div key={key} className="glass rounded-lg overflow-hidden">
                  <div 
                    className="flex items-center p-3 cursor-pointer hover:bg-white/5 transition-colors"
                    onClick={() => toggleModelExpansion(key)}
                  >
                    <input
                      type="checkbox"
                      checked={selectedModels[key].enabled}
                      onChange={() => toggleModel(key)}
                      onClick={(e) => e.stopPropagation()}
                      className="mr-3 accent-primary"
                    />
                    <span className="flex-1 font-medium text-sm">{model.name}</span>
                    {expandedModels[key] ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </div>
                  
                  {expandedModels[key] && (
                    <div className="bg-black/20 space-y-1">
                      {model.options.map((option) => (
                        <label key={option.id} className="flex items-center p-2 pl-8 hover:bg-white/5 cursor-pointer text-sm">
                          <input
                            type="radio"
                            name={key}
                            value={option.id}
                            checked={selectedModels[key].model === option.id}
                            onChange={() => selectModelOption(key, option.id)}
                            className="mr-3 accent-primary"
                          />
                          <span className="flex-1">{option.name}</span>
                          <Badge className={`text-xs ${getPriceClass(option.price)}`}>
                            {option.price}
                          </Badge>
                        </label>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Response Format */}
          <Card className="glass mt-6">
            <CardHeader>
              <CardTitle className="text-lg">Response Format</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {responseFormats.map((format) => (
                  <button
                    key={format}
                    onClick={() => setResponseFormat(format.toLowerCase())}
                    className={`w-full p-2 rounded text-sm transition-colors ${
                      responseFormat === format.toLowerCase()
                        ? 'bg-primary/20 border-primary/50 text-white'
                        : 'bg-white/5 border-white/10 text-muted-foreground hover:bg-white/10'
                    } border`}
                  >
                    {format}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Amalgamation Mode */}
          <Card className="glass mt-6">
            <CardHeader>
              <CardTitle className="text-lg">Amalgamation Mode</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {amalgamationModes.map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setAmalgamationMode(mode.toLowerCase().replace(' ', '-'))}
                    className={`w-full p-2 rounded text-sm transition-colors ${
                      amalgamationMode === mode.toLowerCase().replace(' ', '-')
                        ? 'bg-primary/20 border-primary/50 text-white'
                        : 'bg-white/5 border-white/10 text-muted-foreground hover:bg-white/10'
                    } border`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-2">
          <Card className="glass">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="w-6 h-6 text-primary" />
                <span>AI Amalgamation Engine</span>
              </CardTitle>
              <CardDescription>
                Query multiple AI models and discover variance in responses
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Query Input */}
              <div>
                <Textarea
                  placeholder="Enter your query or select a preset..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="min-h-32 bg-white/5 border-white/10 text-white placeholder:text-muted-foreground"
                />
              </div>

              {/* Preset Templates */}
              <div>
                <h3 className="text-sm font-medium mb-3 opacity-80">Preset Templates</h3>
                <div className="grid grid-cols-2 gap-3">
                  {presets.map((preset) => (
                    <div
                      key={preset.id}
                      onClick={() => setActivePreset(preset.id)}
                      className={`relative overflow-hidden p-3 rounded-lg cursor-pointer transition-all hover:scale-105 ${
                        activePreset === preset.id ? 'ring-2 ring-white/50 scale-105' : ''
                      }`}
                      style={{
                        background: `linear-gradient(135deg, var(--tw-gradient-stops))`,
                      }}
                    >
                      <div className={`absolute inset-0 bg-gradient-to-br ${preset.color} opacity-20`}></div>
                      <div className="relative z-10">
                        <div className="flex justify-between items-start mb-2">
                          <span className="font-medium text-sm text-white">{preset.title}</span>
                          <Badge className={`text-xs border ${preset.tagColor}`}>{preset.tag}</Badge>
                        </div>
                        <p className="text-xs text-gray-300">{preset.desc}</p>
                      </div>
                    </div>
                  ))}
                  <div className="glass p-3 rounded-lg cursor-pointer transition-all hover:bg-white/10 border-2 border-dashed border-white/20 flex flex-col items-center justify-center">
                    <span className="text-2xl opacity-50 mb-1">+</span>
                    <span className="text-xs opacity-70">Add Preset</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between">
                <div className="flex gap-3">
                  <Button className="btn-primary">
                    <Play className="mr-2 w-4 h-4" />
                    Execute Query
                  </Button>
                  <Button variant="outline" className="btn-secondary">
                    Save as Preset
                  </Button>
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <DollarSign className="w-4 h-4" />
                    <span>Est. cost: ${calculateCost()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>Time: ~8s</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Sidebar - Settings */}
        <div className="lg:col-span-1">
          <Card className="glass">
            <CardHeader>
              <CardTitle className="text-lg">Archive Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries({
                'Auto-archive': 'autoArchive',
                'Include metadata': 'includeMetadata',
                'Version control': 'versionControl'
              }).map(([label, key]) => (
                <div key={key} className="flex items-center justify-between">
                  <span className="text-sm">{label}</span>
                  <Switch
                    checked={settings[key]}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, [key]: checked }))}
                  />
                </div>
              ))}
              
              <div className="glass rounded-lg p-3 mt-4">
                <div className="flex items-center gap-2 text-sm">
                  <Settings className="w-4 h-4 opacity-60" />
                  <span>/Drive/AI-Archive/2025/</span>
                  <Button variant="ghost" size="sm" className="ml-auto text-primary text-xs">
                    Change
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="glass mt-6">
            <CardHeader>
              <CardTitle className="text-lg">Performance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries({
                'Streaming mode': 'streamingMode',
                'Cache responses': 'cacheResponses',
                'Batch requests': 'batchRequests'
              }).map(([label, key]) => (
                <div key={key} className="flex items-center justify-between">
                  <span className="text-sm">{label}</span>
                  <Switch
                    checked={settings[key]}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, [key]: checked }))}
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="glass mt-6">
            <CardHeader>
              <CardTitle className="text-lg">Quick Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-2xl font-bold text-primary">247</div>
                  <div className="text-xs text-muted-foreground">Queries today</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-secondary">$18.42</div>
                  <div className="text-xs text-muted-foreground">Daily cost</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-primary">92%</div>
                  <div className="text-xs text-muted-foreground">Cache hit rate</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-secondary">3.2s</div>
                  <div className="text-xs text-muted-foreground">Avg response</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-2 mt-6">
            <Button variant="outline" className="btn-secondary flex-1">
              <Upload className="mr-2 w-4 h-4" />
              Import
            </Button>
            <Button variant="outline" className="btn-secondary flex-1">
              <Download className="mr-2 w-4 h-4" />
              Export
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AIAmalgamationEngine

