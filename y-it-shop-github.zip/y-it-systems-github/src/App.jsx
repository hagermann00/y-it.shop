import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import AIAmalgamationEngine from './components/AIAmalgamationEngine.jsx'
import { 
  Menu, 
  X, 
  ChevronDown, 
  Brain, 
  BookOpen, 
  Cpu, 
  Zap, 
  TrendingUp, 
  Shield, 
  Users,
  ArrowRight,
  Star,
  DollarSign,
  Target,
  BarChart3,
  Settings,
  Play
} from 'lucide-react'
import './App.css'

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState('home')

  // Handle scroll to update active section
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'y-it-guide', 'ai-engine', 'kno-it-stack', 'about']
      const scrollPosition = window.scrollY + 100

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const { offsetTop, offsetHeight } = element
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section)
            break
          }
        }
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
    setIsMenuOpen(false)
  }

  return (
    <div className="min-h-screen animated-bg">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex-shrink-0">
              <h1 className="text-2xl font-bold gradient-text">Y-It Systems</h1>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                {[
                  { id: 'home', label: 'Home' },
                  { id: 'y-it-guide', label: 'Y-It Guide' },
                  { id: 'ai-engine', label: 'AI Engine' },
                  { id: 'kno-it-stack', label: 'Kno-It Stack' },
                  { id: 'about', label: 'About' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      activeSection === item.id
                        ? 'text-white bg-primary/20'
                        : 'text-muted-foreground hover:text-white hover:bg-white/5'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-white hover:bg-white/10 focus:outline-none"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 glass rounded-lg mt-2">
                {[
                  { id: 'home', label: 'Home' },
                  { id: 'y-it-guide', label: 'Y-It Guide' },
                  { id: 'ai-engine', label: 'AI Engine' },
                  { id: 'kno-it-stack', label: 'Kno-It Stack' },
                  { id: 'about', label: 'About' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-white hover:bg-white/10"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-20 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <div className="float mb-8">
              <div className="inline-flex items-center space-x-2 glass rounded-full px-6 py-3 mb-8">
                <Zap className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">Revolutionary AI-Powered Systems</span>
              </div>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="gradient-text">Y-It Systems</span>
              <br />
              <span className="text-white">The Future of AI Intelligence</span>
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Discover the truth about dropshipping with our brutally honest guide, 
              harness the power of multiple AI models with our Amalgamation Engine, 
              and build your own AI research system with the Kno-It Core Stack.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={() => scrollToSection('y-it-guide')}
                className="btn-primary px-8 py-3 text-lg"
              >
                Explore Y-It Guide
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button 
                onClick={() => scrollToSection('ai-engine')}
                variant="outline" 
                className="btn-secondary px-8 py-3 text-lg"
              >
                Try AI Engine
                <Brain className="ml-2 w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Feature Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            <Card className="glass card-hover">
              <CardHeader>
                <BookOpen className="w-12 h-12 text-primary mb-4" />
                <CardTitle className="text-xl">Y-It Dropshipping Guide</CardTitle>
                <CardDescription>
                  Brutally honest expose of dropshipping reality with real statistics and case studies
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2 mb-4">
                  <Badge variant="secondary">92% Failure Rate</Badge>
                  <Badge variant="secondary">Real Data</Badge>
                </div>
                <Button 
                  onClick={() => scrollToSection('y-it-guide')}
                  className="w-full btn-primary"
                >
                  Learn More
                </Button>
              </CardContent>
            </Card>

            <Card className="glass card-hover">
              <CardHeader>
                <Brain className="w-12 h-12 text-primary mb-4" />
                <CardTitle className="text-xl">AI Amalgamation Engine</CardTitle>
                <CardDescription>
                  Query multiple AI models simultaneously and detect variance in responses
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2 mb-4">
                  <Badge variant="secondary">6+ AI Models</Badge>
                  <Badge variant="secondary">Variance Detection</Badge>
                </div>
                <Button 
                  onClick={() => scrollToSection('ai-engine')}
                  className="w-full btn-primary"
                >
                  Try It Now
                </Button>
              </CardContent>
            </Card>

            <Card className="glass card-hover">
              <CardHeader>
                <Cpu className="w-12 h-12 text-primary mb-4" />
                <CardTitle className="text-xl">Kno-It Core Stack</CardTitle>
                <CardDescription>
                  Open-source AI research system for building your own intelligence network
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2 mb-4">
                  <Badge variant="secondary">Open Source</Badge>
                  <Badge variant="secondary">Modular</Badge>
                </div>
                <Button 
                  onClick={() => scrollToSection('kno-it-stack')}
                  className="w-full btn-primary"
                >
                  Get Started
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Y-It Dropshipping Guide Section */}
      <section id="y-it-guide" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="gradient-text">Y-It Dropshipping Guide</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              The brutally honest truth about dropshipping that gurus don't want you to know
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold mb-6">Why This Guide is Different</h3>
              <ul className="space-y-4">
                <li className="flex items-start space-x-3">
                  <Shield className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Brutally Honest</h4>
                    <p className="text-muted-foreground">Real statistics, not fake success stories</p>
                  </div>
                </li>
                <li className="flex items-start space-x-3">
                  <BarChart3 className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Data-Driven</h4>
                    <p className="text-muted-foreground">92% failure rate within 120 days</p>
                  </div>
                </li>
                <li className="flex items-start space-x-3">
                  <Users className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Real Case Studies</h4>
                    <p className="text-muted-foreground">7 disasters + 2 rare success stories</p>
                  </div>
                </li>
                <li className="flex items-start space-x-3">
                  <DollarSign className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">True Costs</h4>
                    <p className="text-muted-foreground">Average $4,000+ startup vs "free" promises</p>
                  </div>
                </li>
              </ul>
            </div>

            <Card className="glass">
              <CardHeader>
                <CardTitle>Key Statistics</CardTitle>
                <CardDescription>The harsh reality of dropshipping</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Failure Rate (120 days)</span>
                  <Badge variant="destructive">92%</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Median Monthly Profit</span>
                  <Badge variant="secondary">$163</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Average Hours/Week</span>
                  <Badge variant="secondary">47</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Make $5,000+/month</span>
                  <Badge variant="secondary">0.6%</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Guru Course Success</span>
                  <Badge variant="secondary">3%</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-12 text-center">
            <Card className="glass max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle>Get the Complete Guide</CardTitle>
                <CardDescription>
                  8 chapters of unfiltered truth about dropshipping reality
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">$9.99</div>
                    <div className="text-sm text-muted-foreground">Director's Cut</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">FREE</div>
                    <div className="text-sm text-muted-foreground">Mini Guide</div>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button className="btn-primary flex-1">
                    Download Full Guide
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                  <Button variant="outline" className="btn-secondary flex-1">
                    Get Free Sample
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* AI Amalgamation Engine Section */}
      <section id="ai-engine" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="gradient-text">AI Amalgamation Engine</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Query multiple AI models simultaneously and discover the variance in their responses
            </p>
          </div>

          <AIAmalgamationEngine />

        </div>
      </section>

      {/* Kno-It Core Stack Section */}
      <section id="kno-it-stack" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="gradient-text">Kno-It Core Stack</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              A modular, agentic, multi-context automation system for research, execution, and discovery
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            <div>
              <h3 className="text-2xl font-bold mb-6">Core Philosophy</h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-3">
                  <Target className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Variance Over Average</h4>
                    <p className="text-muted-foreground">
                      Focus on edge cases and contradictions, not consensus
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Shield className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Local-First Architecture</h4>
                    <p className="text-muted-foreground">
                      Run on your own hardware, maintain full control
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Brain className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Multi-Agent System</h4>
                    <p className="text-muted-foreground">
                      Specialized agents for different research tasks
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Settings className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold">Self-Auditing Intelligence</h4>
                    <p className="text-muted-foreground">
                      Tracks patterns and learns from contradictions
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <Card className="glass">
              <CardHeader>
                <CardTitle>System Architecture</CardTitle>
                <CardDescription>Modular components working together</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 font-mono text-sm">
                  <div className="text-primary">/kno-it-agent/</div>
                  <div className="ml-4">├── prompt_watcher.py</div>
                  <div className="ml-4">├── agent_planner.py</div>
                  <div className="ml-4">├── ai_runner.py</div>
                  <div className="ml-4">├── brave_injector.sh</div>
                  <div className="ml-4">├── memory_log.json</div>
                  <div className="ml-4">├── google_drive_uploader.py</div>
                  <div className="ml-4">├── notebooklm_pusher.py</div>
                  <div className="ml-4">├── tts_summarizer.py</div>
                  <div className="ml-4">└── identifier_agent.py</div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-12">
            <Card className="glass">
              <CardHeader>
                <CardTitle>Operational Loop</CardTitle>
                <CardDescription>How the system processes information</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {[
                    { step: 1, title: "Prompt Detection", desc: "Watches for new queries" },
                    { step: 2, title: "Task Planning", desc: "Breaks down complex requests" },
                    { step: 3, title: "Multi-Model Execution", desc: "Queries multiple AIs" },
                    { step: 4, title: "Variance Analysis", desc: "Identifies contradictions" }
                  ].map((item) => (
                    <div key={item.step} className="text-center">
                      <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-3">
                        <span className="text-primary font-bold">{item.step}</span>
                      </div>
                      <h4 className="font-semibold mb-2">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8 text-center">
            <Button className="btn-primary px-8 py-3">
              Download Kno-It Stack
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            <span className="gradient-text">About Y-It Systems</span>
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            We build tools that reveal truth through variance, not consensus. 
            Our systems are designed to surface contradictions, identify edge cases, 
            and provide the 20% of insights that break the rules.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Honest Content</h3>
              <p className="text-muted-foreground">
                No hype, no false promises. Just brutal honesty backed by data.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">AI Innovation</h3>
              <p className="text-muted-foreground">
                Cutting-edge AI tools that reveal what others miss.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Cpu className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Open Source</h3>
              <p className="text-muted-foreground">
                Transparent systems you can audit, modify, and control.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 border-t border-white/10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h3 className="text-2xl font-bold gradient-text mb-4">Y-It Systems</h3>
            <p className="text-muted-foreground mb-6">
              Revealing truth through variance, not consensus
            </p>
            <div className="flex justify-center space-x-6">
              <Button variant="ghost" className="text-muted-foreground hover:text-white">
                Documentation
              </Button>
              <Button variant="ghost" className="text-muted-foreground hover:text-white">
                GitHub
              </Button>
              <Button variant="ghost" className="text-muted-foreground hover:text-white">
                Contact
              </Button>
            </div>
            <div className="mt-8 pt-8 border-t border-white/10">
              <p className="text-sm text-muted-foreground">
                © 2025 Y-It Systems. Built for truth seekers and variance detectors.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

